import { MongoClient } from "mongodb";
import { MONGO_URI } from "./env.js";

export const gestorDB = {
  client: null,
  db: null,

  async connect() {
    this.client = new MongoClient(MONGO_URI);  
    await this.client.connect();
    this.db = this.client.db("CrazyCarlosDB"); 
  },

  getCollection(dbName, collectionName) {
    return this.client.db(dbName).collection(collectionName);
  }
  
};

