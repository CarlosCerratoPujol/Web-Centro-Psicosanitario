export const PORT = 3000;

export const MONGO_URI = "mongodb://localhost:27017"; 

