Carlos Cerrato Pujol
CGIS Curso 24/25