document.addEventListener('DOMContentLoaded', () => {
  const lista = document.getElementById('listaProfesionales');
  const buscarNombre = document.getElementById('buscarNombre');
  const filtrarEspecialidad = document.getElementById('filtrarEspecialidad');
  const filtrarCentro = document.getElementById('filtrarCentro');

  function mostrarDetalle(index) {
    const pro = profesionales[index];
    document.getElementById('detalleNombre').innerText = `${pro.nombre} ${pro.apellidos}`;
    document.getElementById('detalleEspecialidad').innerText = pro.especialidad;
    document.getElementById('detalleCentro').innerText = pro.centro;
    document.getElementById('detalleHorario').innerText = pro.horario;
  }

  function filtrarProfesionales() {
    const textoNombre = buscarNombre.value.toLowerCase();
    const especialidadSeleccionada = filtrarEspecialidad.value;
    const centroSeleccionado = filtrarCentro.value;

    lista.innerHTML = '';

    profesionales.forEach((pro, index) => {
      const coincideNombre = `${pro.nombre} ${pro.apellidos}`.toLowerCase().includes(textoNombre);
      const coincideEspecialidad = !especialidadSeleccionada || pro.especialidad === especialidadSeleccionada;
      const coincideCentro = !centroSeleccionado || pro.centro === centroSeleccionado;

      if (coincideNombre && coincideEspecialidad && coincideCentro) {
        const li = document.createElement('li');
        li.className = 'list-group-item d-flex justify-content-between align-items-center';
        li.innerHTML = `
          <div>
            <h5 class="mb-1">${pro.nombre} ${pro.apellidos}</h5>
            <p class="mb-0"><strong>Especialidad:</strong> ${pro.especialidad} | <strong>Centro:</strong> ${pro.centro}</p>
          </div>
          <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalDetalle"
            data-index="${index}">Ver Detalle</button>
        `;
        lista.appendChild(li);
      }
    });
  }

  // Eventos
  buscarNombre.addEventListener('keyup', filtrarProfesionales);
  filtrarEspecialidad.addEventListener('change', filtrarProfesionales);
  filtrarCentro.addEventListener('change', filtrarProfesionales);

  lista.addEventListener('click', (e) => {
    if (e.target.tagName === 'BUTTON' && e.target.hasAttribute('data-index')) {
      const index = e.target.getAttribute('data-index');
      mostrarDetalle(index);
    }
  });
});
