import { Router } from "express";
import citasModel from "../model/citasModel.js";

const router = Router();

// Página para solicitar cita
router.get("/", (req, res) => {
  res.render("pages/citas", {
    title: "Solicitar Cita",
    mensaje: req.query.confirmada === "1" ? "Cita confirmada con éxito." : null
  });
});

// Guardar nueva cita
router.post("/", async (req, res) => {
  const { nombre, email, especialidad, centro, fecha } = req.body;

  if (!nombre || !email || !especialidad || !centro || !fecha) {
    return res.status(400).render("pages/error", {
      title: "Error",
      error: "Todos los campos son obligatorios"
    });
  }

  const cita = { nombre, email, especialidad, centro, fecha };
  await citasModel.insertarCita(cita);
  

  res.redirect("/citas?confirmada=1");
});

// Formulario para consultar cita
router.get("/consultar", (req, res) => {
  let mensaje = null;
  if (req.query.editada === "1") mensaje = "Cita editada con éxito.";
  if (req.query.cancelada === "1") mensaje = "Cita cancelada con éxito.";

  res.render("pages/consultarCita", {
    title: "Consultar Cita",
    error: null,
    cita: null,
    noEncontrada: false,
    mensaje
  });
});

// Procesar búsqueda de cita
router.post("/consultar", async (req, res) => {
  const { nombre, email } = req.body;

  if (!nombre || !email) {
    return res.render("pages/consultarCita", {
      title: "Consultar Cita",
      cita: null,
      noEncontrada: true,
      error: null,
      mensaje: null
    });
  }

  try {
    const cita = await citasModel.buscarPorNombreYEmail(nombre, email);
    if (cita) {
      res.render("pages/consultarCita", {
        title: "Consultar Cita",
        cita,
        noEncontrada: false,
        error: null,
        mensaje: null
      });
    } else {
      res.render("pages/consultarCita", {
        title: "Consultar Cita",
        cita: null,
        noEncontrada: true,
        error: null,
        mensaje: null
      });
    }
  } catch (error) {
    res.status(500).render("pages/error", {
      title: "Error",
      error: error.message
    });
  }
});

// Actualizar una cita existente
router.post("/editar/:id", async (req, res) => {
  const { nombre, email, especialidad, centro, fecha } = req.body;
  await citasModel.actualizarCita(req.params.id, {
    nombre,
    email,
    especialidad,
    centro,
    fecha
  });

  res.redirect("/citas/consultar?editada=1");
});

// Borrar una cita
router.post("/borrar/:id", async (req, res) => {
  await citasModel.borrarCita(req.params.id);
  res.redirect("/citas/consultar?cancelada=1");
});

export default router;
