import { Router } from "express";
const router = Router();

// Datos de los centros
const centros = [
  {
    nombre: "Centro Sur - Sevilla",
    direccion: "Avda. de la Salud 123, Sevilla",
    telefono: "955 111 111"
  },
  {
    nombre: "Centro Norte - Triana",
    direccion: "Calle Bienestar 45, Sevilla",
    telefono: "955 222 222"
  },
  {
    nombre: "Centro Este - Nervión",
    direccion: "Plaza Tranquilidad 8, Sevilla",
    telefono: "955 333 333"
  }
];

// Ruta principal de Centros
router.get("/", (req, res) => {
  res.render("pages/centros", { title: "Nuestros Centros", centros });
});

export default router;
