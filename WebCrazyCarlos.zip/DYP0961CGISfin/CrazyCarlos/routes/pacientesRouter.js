// routes/pacientesRouter.js
import { Router } from "express";
import pacientesModel from "../model/pacientesModel.js";

const router = Router();

router.get("/", (req, res) => {
  res.render("pages/pacientesAlta", { title: "Alta de Paciente", mensaje: null });
});

router.post("/", async (req, res) => {
  const { nombre, email, telefono, fechaNacimiento, direccion } = req.body;
  if (!nombre || !email || !telefono || !fechaNacimiento || !direccion) {
    return res.render("pages/pacientesAlta", {
      title: "Alta de Paciente",
      mensaje: "Todos los campos son obligatorios"
    });
  }

  const pacienteExistente = await pacientesModel.buscarPorEmail(email);
  if (pacienteExistente) {
    return res.render("pages/pacientesAlta", {
      title: "Alta de Paciente",
      mensaje: "Ya existe un paciente con ese email."
    });
  }

  await pacientesModel.insertarPaciente({ nombre, email, telefono, fechaNacimiento, direccion });
  res.render("pages/pacientesAlta", {
    title: "Alta de Paciente",
    mensaje: "Paciente registrado con éxito"
  });
});

router.get("/editar", (req, res) => {
  res.render("pages/pacientesEditar", {
    title: "Editar/Baja Paciente",
    paciente: null,
    mensaje: null,
    error: null
  });
});

router.post("/editar", async (req, res) => {
  const { email } = req.body;
  const paciente = await pacientesModel.buscarPorEmail(email);

  if (!paciente) {
    return res.render("pages/pacientesEditar", {
      title: "Editar/Baja Paciente",
      paciente: null,
      mensaje: null,
      error: "No se encontró paciente con ese email"
    });
  }

  res.render("pages/pacientesEditar", {
    title: "Editar/Baja Paciente",
    paciente,
    mensaje: null,
    error: null
  });
});

router.post("/actualizar/:id", async (req, res) => {
  const { nombre, email, telefono, fechaNacimiento, direccion } = req.body;
  await pacientesModel.actualizarPaciente(req.params.id, {
    nombre, email, telefono, fechaNacimiento, direccion
  });

  res.redirect("/pacientes/editar?msg=editado");
});

router.post("/borrar/:id", async (req, res) => {
  await pacientesModel.borrarPaciente(req.params.id);
  res.redirect("/pacientes/editar?msg=borrado");
});

export default router;
