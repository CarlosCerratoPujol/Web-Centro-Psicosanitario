// routes/indexRouter.js
import { Router } from "express";
import centrosRouter from "./centrosRouter.js";
import serviciosRouter from "./serviciosRouter.js";
import citasRouter from "./citasRouter.js";
import informacionRouter from "./informacionRouter.js";
import pacientesRouter from "./pacientesRouter.js";

const router = Router();

// Página de inicio
router.get("/", (req, res) => {
  res.render("pages/index", { title: "Inicio" });
});

// Sub-routes
router.use("/centros", centrosRouter);
router.use("/servicios", serviciosRouter);
router.use("/citas", citasRouter);
router.use("/informacion", informacionRouter);
router.use("/pacientes", pacientesRouter);

// Ruta 404 (importante que sea el último router.use)
router.use((req, res) => {
  res.status(404).render("partials/404", { title: "Página no encontrada" });
});

export default router;

