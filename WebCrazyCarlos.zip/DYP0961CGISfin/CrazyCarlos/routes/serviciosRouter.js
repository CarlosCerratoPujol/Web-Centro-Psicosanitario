import { Router } from "express";
import profesionalesModel from "../model/profesionalesModel.js";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const profesionales = await profesionalesModel.obtenerTodos();

    const especialidadesUnicas = [...new Set(profesionales.map(p => p.especialidad))];
    const centrosUnicos = [...new Set(profesionales.map(p => p.centro))];

    res.render("pages/servicios", { 
      title: "Nuestros Profesionales", 
      profesionales, 
      especialidadesUnicas, 
      centrosUnicos 
    });
  } catch (error) {
    console.error("*** Error en serviciosRouter:", error.message);
    res.status(500).render("partials/404", { title: "Error interno" });
  }
});

export default router;
