// index.js
import express from "express";
import path from "path";
import { fileURLToPath } from "url";

import { PORT } from "./config/env.js";
import { gestorDB } from "./config/database.js";

import indexRouter from "./routes/indexRouter.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Archivos estáticos
app.use(express.static(path.join(__dirname, "public")));

// Configuración de EJS
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rutas
app.use("/", indexRouter);

// Conexión a la base de datos y arranque del servidor
async function startServer() {
  try {
    await gestorDB.connect();
    app.locals.db = gestorDB;
    app.listen(PORT, () => {
      console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error("❌ Error al conectar a la base de datos:", error.message);
    process.exit(1);
  }
}

startServer();

