import { gestorDB } from "../config/database.js";

const DB_NAME = "CrazyCarlosDB";  
const COLLECTION_NAME = "Profesionales"; 

const profesionalesModel = {
  async obtenerTodos() {
    try {
      const coleccion = gestorDB.getCollection(DB_NAME, COLLECTION_NAME);
      

      const profesionales = await coleccion.find({}).toArray();
      

      return profesionales;
    } catch (error) {
      console.error("*** Error en profesionalesModel.obtenerTodos:", error.message);
      throw error;
    }
  }
};

export default profesionalesModel;

