// model/pacientesModel.js
import { gestorDB } from "../config/database.js";
import { ObjectId } from "mongodb";

const DB_NAME = "CrazyCarlosDB";
const COLLECTION_NAME = "Pacientes";

const pacientesModel = {
  async insertarPaciente(paciente) {
    const coleccion = gestorDB.getCollection(DB_NAME, COLLECTION_NAME);
    await coleccion.insertOne(paciente);
  },

  async buscarPorEmail(email) {
    const coleccion = gestorDB.getCollection(DB_NAME, COLLECTION_NAME);
    return await coleccion.findOne({ email });
  },

  async actualizarPaciente(id, nuevosDatos) {
    const coleccion = gestorDB.getCollection(DB_NAME, COLLECTION_NAME);
    await coleccion.updateOne({ _id: new ObjectId(id) }, { $set: nuevosDatos });
  },

  async borrarPaciente(id) {
    const coleccion = gestorDB.getCollection(DB_NAME, COLLECTION_NAME);
    await coleccion.deleteOne({ _id: new ObjectId(id) });
  }
};

export default pacientesModel;
