import { gestorDB } from "../config/database.js";
import { ObjectId } from "mongodb";

const DB_NAME = "CrazyCarlosDB";
const COLLECTION_NAME = "Citas";

const citasModel = {
  async insertarCita(cita) {
    const coleccion = gestorDB.getCollection(DB_NAME, COLLECTION_NAME);
    await coleccion.insertOne(cita);
  },

  async buscarPorNombreYEmail(nombre, email) {
    const coleccion = gestorDB.getCollection(DB_NAME, COLLECTION_NAME);
    return await coleccion.findOne({ nombre, email });
  },

  async actualizarCita(id, nuevosDatos) {
    const coleccion = gestorDB.getCollection(DB_NAME, COLLECTION_NAME);
    await coleccion.updateOne({ _id: new ObjectId(id) }, { $set: nuevosDatos });
  },
  
  async borrarCita(id) {
    const coleccion = gestorDB.getCollection(DB_NAME, COLLECTION_NAME);
    await coleccion.deleteOne({ _id: new ObjectId(id) });
  }
};

export default citasModel;
